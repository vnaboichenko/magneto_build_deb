MagnetoDB
=========

**MagnetoDB** - NoSQL database service for OpenStack


Links
------------------
Wiki - https://wiki.openstack.org/wiki/MagnetoDB

IRC - #magnetodb at FreeNode

Source code - https://github.com/stackforge/magnetodb

Deployment - https://github.com/stackforge/magnetodb/blob/master/doc/deploy_magnetodb_howto.rst
